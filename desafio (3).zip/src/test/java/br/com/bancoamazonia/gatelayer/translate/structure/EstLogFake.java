package br.com.bancoamazonia.gatelayer.translate.structure;

import br.com.bancoamazonia.gatelayer.translate.PositionalField;

public class EstLogFake {
    @PositionalField(length = 5, description = "Sem descrição")
    private String campo1;
    @PositionalField(length = 5, description = "Sem descrição")
    private String campo2;
}
