package br.com.bancoamazonia.gatelayer.translate.exception;

public class TypeConvertException extends RuntimeException {
    public TypeConvertException(String message) {
        super(message);
    }
}
