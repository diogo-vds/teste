package br.com.bancoamazonia.gatelayer.translate.exception;

public class PositionalBuildException extends RuntimeException {
    public PositionalBuildException(String message) {
        super(message);
    }
}
